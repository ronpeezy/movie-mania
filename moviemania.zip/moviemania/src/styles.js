
export const inputStyles = {
    display: 'block',
    width: '100%',
    marginTop: 30,
    background: '#212121',
    color: '#ffffff',
    border: 'none',
    height: 30,
    outline: 0,
    fontSize: 18,
    padding: 25
};